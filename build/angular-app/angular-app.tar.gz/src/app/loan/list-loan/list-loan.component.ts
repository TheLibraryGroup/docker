import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-list-loan',
  templateUrl: './list-loan.component.html',
  styleUrls: ['./list-loan.component.css']
})
export class ListLoanComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }
}
