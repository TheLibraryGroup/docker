import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {LastReleaseRoutingModule} from './last-release-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LastReleaseRoutingModule
  ]
})
export class LastReleaseModule { }
